<?php
namespace Brickstorm\SolidRBundle\Controller\Admin;

use Sonata\AdminBundle\Controller\CRUDController as Controller;

class AreaAdminController extends Controller
{

}